# OrganOngle
Extension Firefox qui regroupe les onglets ouverts par domaine, en grille, et permet de les fermer à la volée.

Extension créé à l'aide de chatGPT v4
