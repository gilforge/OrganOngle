# Placeholder pour icon.png

Pour compléter l'installation, vous devez ajouter un fichier icon.png (48x48 pixels) dans le dossier icons/.

Vous pouvez :
1. Utiliser l'icône de votre version précédente
2. Créer une nouvelle icône 48x48 pixels
3. Utiliser un générateur d'icônes en ligne

L'icône doit être nommée "icon.png" et placée dans le dossier icons/.